const contract = require('./operator005_contract.js');
const R = require('./document_resolver.js');

let passed = 0;
let failed = 0;
const details = [];

function test(name, fn) {
  try {
    fn();
    passed += 1;
    details.push({ name, status: 'PASS' });
  } catch (e) {
    failed += 1;
    details.push({ name, status: 'FAIL', error: e.message });
  }
}
function eq(actual, expected, label) {
  if (actual !== expected) throw new Error(`${label}: expected=${expected} actual=${actual}`);
}
function ok(value, label) {
  if (!value) throw new Error(label);
}

test('operator005 exists', () => eq(R.getWorker(contract, '005').status, 'PASS', 'worker'));
test('worker to unit exact', () => {
  const a = R.getAssignmentForWorker(contract, '005');
  eq(a.status, 'PASS', 'assignment');
  eq(a.value.unit_id, 'U005-01', 'unit id');
});
test('unit to product exact', () => {
  const u = R.getUnit(contract, 'U005-01');
  const p = R.getProduct(contract, u.value.product_id);
  eq(p.status, 'PASS', 'product');
  eq(p.value.product_id, 'P7330397', 'product id');
  ok(u.value.unit_id !== p.value.product_id, 'MODEL_UNIT_CONFUSION');
});
test('product to current manual exact', () => {
  const m = R.getCurrentManual(contract, 'P7330397', contract.generated_at);
  eq(m.status, 'PASS', 'manual');
  eq(m.value.document_id, 'MANUAL_ENERGY_6801849_2024_12', 'manual id');
});
test('document source page exact', () => {
  const s = R.getSourceForField(contract, 'MANUAL_ENERGY_6801849_2024_12', 'PRODUCT_COVERAGE');
  eq(s.status, 'PASS', 'source');
  eq(s.value.pages[0], 1, 'page');
});
test('founder query complete response', () => {
  const a = R.answerFounderQuery(contract, '005');
  eq(a.status, 'PASS', 'founder answer');
  const required = ['WORKER','ASSIGNMENT','UNIT','PRODUCT','MANUFACTURER','DOCUMENT_TITLE','DOCUMENT_VERSION','DOCUMENT_DATE','SOURCE','PAGE','LOCAL_COPY','SHA256','STATUS','WHY_SELECTED'];
  for (const k of required) ok(Object.prototype.hasOwnProperty.call(a.value, k), `missing ${k}`);
  eq(a.value.STATUS, 'PARTIAL_SOURCE_BYTES_NOT_MATERIALIZED', 'materialization status');
});
test('wrong worker fails closed', () => eq(R.answerFounderQuery(contract, '999').status, 'NON_VERIFICATO', 'wrong worker'));
test('wrong unit fails closed', () => eq(R.getUnit(contract, 'U999').status, 'NON_VERIFICATO', 'wrong unit'));
test('wrong product fails closed', () => eq(R.getCurrentManual(contract, 'P999', contract.generated_at).status, 'NON_VERIFICATO', 'wrong product'));
test('wrong manual fails closed', () => eq(R.getSourceForField(contract, 'D999', 'PRODUCT_COVERAGE').status, 'NON_VERIFICATO', 'wrong manual'));
test('wrong source field fails closed', () => eq(R.getSourceForField(contract, 'MANUAL_ENERGY_6801849_2024_12', 'UNKNOWN_FIELD').status, 'NON_VERIFICATO', 'wrong field'));
test('future-version leakage blocked', () => {
  const e = R.selectDocumentVersionAtDate(contract.event_time_fixture.versions, contract.event_time_fixture.event_at);
  eq(e.status, 'PASS', 'event lookup');
  eq(e.value.document_id, 'D-ET-V1', 'event version');
  ok(e.value.document_id !== 'D-ET-V2', 'future version leaked');
});
test('formation and addestramento remain separate', () => {
  eq(contract.worker.formation.status, 'PROVATA', 'formation');
  eq(contract.worker.addestramento.status, 'NON_VERIFICATO', 'addestramento');
  ok(!Object.prototype.hasOwnProperty.call(contract.worker, 'trained'), 'TRAINED false green');
});
test('missing evidence is not negative', () => {
  const u = R.getUnit(contract, 'U005-01').value;
  eq(u.expiry, 'NON_VERIFICATO', 'expiry');
  ok(u.expiry !== 'NO', 'missing interpreted as negative');
});
test('false suitability blocked', () => {
  const u = R.getUnit(contract, 'U005-01').value;
  eq(u.claims.safe, 'NON_VERIFICATO', 'safe');
  eq(u.claims.fit_for_use, 'NON_VERIFICATO', 'fit');
});
test('false recall match blocked', () => {
  const p = R.getProduct(contract, 'P7330397').value;
  eq(p.safety_status, 'NOT_FOUND', 'safety status');
  ok(p.safety_status !== 'SAFE', 'false safety/recall green');
});
test('model unit confusion blocked by resolver', () => {
  eq(R.getProduct(contract, 'U005-01').status, 'NON_VERIFICATO', 'unit used as product');
  eq(R.getUnit(contract, 'P7330397').status, 'NON_VERIFICATO', 'product used as unit');
});

const gate = R.evaluateGate(contract);
for (const [k, v] of Object.entries(gate)) {
  if (k === 'FALSE_GREEN') eq(v, 0, k);
  else if (k === 'OPERATOR_005_MATERIALIZED') eq(v, 'YES', k);
  else eq(v, 'PASS', k);
}

const summary = {
  TESTS_TOTAL: passed + failed,
  TESTS_PASS: passed,
  TESTS_FAIL: failed,
  FALSE_GREEN: gate.FALSE_GREEN,
  SUCCESS_GATE: gate,
  DETAILS: details
};
console.log(JSON.stringify(summary, null, 2));
if (failed > 0) process.exit(1);
